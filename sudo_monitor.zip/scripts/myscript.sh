#!/bin/bash
# myscript.sh - Test script from the assignment

echo "ls..."
ls

echo "Create a directory in /opt (requires root privileges)..."
mkdir /opt/my_new_directory

echo "Done!"
