This project implements a sudo I/O plugin in C++20 that monitors privileged command execution.
The main task captures comprehensive process data (PID, path, owner, permissions, environment) and outputs to both console and log file.
Bonus Task 1 (child process detection) is achieved by scanning /proc during I/O events, allowing us to catch short-lived child processes while they're still running.

## Building

```bash
make
```

Requires GCC 10+ or Clang 10+ with C++20 support.

## Installing

```bash
make install
```

## Testing

```bash
sudo ls
sudo ./scripts/myscript.sh
cat /var/log/sudo_monitor.log
```

## Uninstalling

```bash
make uninstall
```